<?php

require_once('../app/bootstrap.php');
// Init Core Library

route();
