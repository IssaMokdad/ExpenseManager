<?php

class Users extends Controller {
    private $UserService;
    private $EmployeeService;

    public function __construct()
    {
        $this->UserService = new UserService();
    }

    public function register()
    {
        $this->UserService->register();
        $this->view('users/register');
    }
    public function login(){
        $this->UserService->login();
        $this->view('users/login');
    }

    public function logout(){
        unset($_SESSION['is_logged_in']);
        unset($_SESSION['user_data']);
        session_destroy();
        // Redirect
        redirect('users/login');
    }
}