<?php

class Expenses extends Controller {

    private $ExpenseService;
    private $CategoryService;

    public function __construct()
    {
        $this->ExpenseService = new ExpensesService();
        $this->CategoryService = new CategoriesService();
    }

    public function index()
    {
        try {
            $data = [
                'data' => 1
            ];
            $this->view('expenses/index',$data );
        } catch (Exception $e) {
            http_response_code(404);
            echo json_encode(array("message" => $e->getMessage()));
        }
    }

//    public function show($id)
//    {
//        try {
//            $data = $this->ExpenseService->getExpenseById($id);
//            http_response_code(200);
//
//            echo json_encode($data);
//        }catch (Exception $e){
//            http_response_code(404);
//            echo json_encode(array("message" => "Expense NOT Found."));
//        }
//    }
//
//    public function create(){
//
//        try {
//            $data = $this->CategoryService->getCategories();
//            http_response_code(200);
//            echo json_encode($data);
//        }catch (Exception $e){
//            http_response_code(404);
//        }
//
//        $user_id = $_SESSION['user_id'];
//        $data = json_decode(file_get_contents("php://input"));
//        $expense = new ExpensesModel(null,$user_id,$data->date,$data->amount,$data->category_id);
//
//        try {
//            $this->ExpenseService->addExpense($expense);
//            http_response_code(201);
//            echo json_encode(array("message" => "Expense was created."));
//        }catch (Exception $e){
//            http_response_code(404);
//            echo json_encode(array("message" => "Expense was not created."));
//        }
//    }
//
//    public function update($id){
//        $user_id = $_SESSION['user_id'];
//
//        $data = json_decode(file_get_contents("php://input"));
//
//        $expense = new ExpensesModel($id,$user_id,$data->date,$data->amount,$data->category_id);
//
//
//        try {
//            $this->ExpenseService->updateExpense($expense);
//            http_response_code(200);
//            echo json_encode(array("message" => "Expense was updated."));
//        }catch (Exception $e){
//            http_response_code(404);
//            echo json_encode(array("message" => "Expense was not updated."));
//        }
//    }
//
//    public function delete($id)
//    {
//            try {
//                $this->ExpenseService->deleteExpense($id);
//                http_response_code(200);
//                echo json_encode(array("message" => "Expense was deleted."));
//            } catch (Exception $e) {
//                http_response_code(404);
//                echo json_encode(array("message" => "Expense was not deleted."));
//            }
//    }

}