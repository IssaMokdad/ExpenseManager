<?php

class Categories extends Controller {

    private $CategoryService;

    public function __construct()
    {
        $this->CategoryService = new CategoriesService();
    }

    public function index()
    {
        try {
            $this->view('categories/index');
        } catch (Exception $e) {
            http_response_code(404);
            echo json_encode(array("message" => $e->getMessage()));
        }
    }

}