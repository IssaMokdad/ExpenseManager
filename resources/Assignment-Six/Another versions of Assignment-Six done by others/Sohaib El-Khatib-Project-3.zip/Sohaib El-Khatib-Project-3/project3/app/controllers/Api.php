<?php

class Api extends Controller {

    public function index(){
        $this->api('index');
    }
}
