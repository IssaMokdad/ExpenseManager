<?php
require_once '../app/services/service.php';
/*
 *  CORE CONTROLLER CLASS
 *  Loads Models & Views
 */
class Controller {
    //load model from controllers
    public function model($model){
        // Require model file
        require_once '../app/models/' . $model . '.php';
        // Instantiate model
        return new $model();
    }

    //load view from controllers
    public function view($url, $data = []){
        // Check for view file
        if(file_exists('../app/views/'.$url.'.php')){
            // Require view file
            $urlArray = explode('/',$url);
            require_once '../app/views/'.$url.'.php';
            $fun_name = "$urlArray[0]_index_view";
            $fun_name($data);
        } else {
            // No view exists
            die('View does not exist');
        }
    }

    //load view from controllers
    public function api($url, $data = []){
        // Check for view file
        if(file_exists('../app/api/'.$url.'.php')){
            // Require view file
            require_once '../app/api/'.$url.'.php';
        } else {
            // No view exists
            die('api does not exist');
        }
    }

}