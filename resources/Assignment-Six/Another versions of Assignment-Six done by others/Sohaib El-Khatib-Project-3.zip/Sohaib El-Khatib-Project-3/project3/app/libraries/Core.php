<?php

function route(){
    $currentController = null;
    $controller = 'Expenses';
    $currentMethod = 'index';
    $params = [];
    $param = [];
    $url = getUrl();

    if(isset($url[2])){
        if(file_exists('../app/controllers/'.ucwords($url[2]).'.php')){
            $controller = ucwords($url[2]);
            unset($url[2]);
        }
    }
    require_once('../app/controllers/'.$controller.'.php');

    $currentController = new $controller;

    if(isset($url[3])){
        if(method_exists($currentController, $url[3])){
            $currentMethod = $url[3];
            unset($url[3]);
        }
    }

    $params = $url ? array_values($url) : [];

    if (isset($params[2])){
        $param = $params[2];
    }
    call_user_func_array([$currentController, $currentMethod], array((int)$param));
}

function getUrl(){
    if(isset($_SERVER['REQUEST_URI'])){
        $url = rtrim($_SERVER['REQUEST_URI'], '/');
        $url = filter_var($url, FILTER_SANITIZE_URL);
        $url = explode('/', $url);
        return $url;
    }
}


