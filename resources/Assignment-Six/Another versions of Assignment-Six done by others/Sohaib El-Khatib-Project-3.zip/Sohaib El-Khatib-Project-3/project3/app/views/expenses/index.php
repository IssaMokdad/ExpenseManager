<?php
function expenses_index_view($data){
var_dump($data);
    ?>
<?php require APPROOT . '/views/inc/header.php'; ?>

    <div id="dialog-form" title="Create new Expense">
        <form method="post" class="form-control" id="addExpenseForm">
            <label for="date">Date</label>
            <input type="date" name="date" id="date" class="input-group">
            <label for="amount">Amount</label>
            <input type="number" name="amount" id="amount" class="input-group">
            <label for="type">Type</label>
            <select name="type" id="type" class="input-group">
            </select>
            <input type="button" value="cancel" class="btn btn-warning" id="cancelForm">
            <input type="submit" class="btn btn-success">
        </form>
    </div>

    <div id="edit-form" title="Update Expense">
        <form method="post" class="form-control" id="editExpenseForm">
            <label for="date">Date</label>
            <input type="date" name="date" id="edit-date" class="input-group">
            <label for="amount">Amount</label>
            <input type="number" name="amount" id="edit-amount" class="input-group">
            <label for="type">Type</label>
            <select name="type" id="edit-type" class="input-group">
            </select>
            <input type="number" id="editElementId" hidden>
            <input type="button" value="cancel" class="btn btn-warning" id="cancelEditForm">
            <input type="submit" class="btn btn-success">
        </form>
    </div>
    <div class="row" style="float: right; margin-right: 5%">
        <div class="col">
            <div class="card card-body" style="width:300px;">
                <label for="search-input">Search Categories Table</label>
                <input type="text" id="search-input" class="form-control" style="width:250px">
            </div>
        </div>
    </div>
    <div id="divTable">
        <div id="addButtonDiv"></div>
        <br>
        <table id="myTable" class="table table-bordered"></table>
        <br>
        <div class="container-page">
            <div id="pagination-wrapper"></div>
        </div>
    </div>

    <div id="divPieChart">
        <!--        <canvas id="myChart" width="400" height="400"></canvas>-->
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
    <script src="/app/assets/js/expenses.js"></script>
<?php require APPROOT . '/views/inc/footer.php'; ?>
<?php } ?>
