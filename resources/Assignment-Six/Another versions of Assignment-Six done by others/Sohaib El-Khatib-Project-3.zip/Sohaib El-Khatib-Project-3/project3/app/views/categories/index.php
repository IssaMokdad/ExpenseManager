<?php
function categories_index_view($data){
    var_dump($data);
    ?>
<?php require APPROOT . '/views/inc/header.php'; ?>
    <div id="dialog-form" title="Create new Category">
        <form method="post" class="form-control" id="addCategoryForm">
            <label for="type">Category Type</label>
            <input type="text" name="type" id="type" class="input-group">
            <input type="button" value="cancel" class="btn btn-warning" id="cancelForm">
            <input type="submit" class="btn btn-success">
        </form>
    </div>

    <div id="edit-form" title="Update Category">
        <form method="post" class="form-control" id="editCategoryForm">
            <label for="edit-type">Category Type</label>
            <input type="text" name="type" id="edit-type" class="input-group">
            <input type="number" id="editElementId" hidden>
            <input type="button" value="cancel" class="btn btn-warning" id="cancelEditForm">
            <input type="submit" class="btn btn-success">
        </form>
    </div>
<div class="row" style="float: right; margin-right: 5%">
    <div class="col">
        <div class="card card-body" style="width:300px;">
            <label for="search-input">Search Categories Table</label>
            <input type="text" id="search-input" class="form-control" style="width:250px">
        </div>
    </div>
</div>
    <div id="editDivTable">
        <div id="addButtonDiv"></div>
        <br>
        <table id="myTable" class="table"></table>
        <br>
        <div class="container-page">
            <div id="pagination-wrapper"></div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="/app/assets/js/categories.js"></script>
<?php require APPROOT . '/views/inc/footer.php'; ?>
<?php } ?>
