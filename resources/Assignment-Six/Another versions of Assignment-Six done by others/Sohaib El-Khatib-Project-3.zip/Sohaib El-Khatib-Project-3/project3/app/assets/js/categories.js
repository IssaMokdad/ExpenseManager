class ExpensesService {
    constructor() {
    }

    async getAllCategories(){
        return fetch('/app/api/index.php?section=getCategories').then(function (response) {
            return response.json();
        });
    }

    async addNewCategory(data){
        return fetch('/app/api/index.php?section=addCategory', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    editCategory(data){
        return fetch('/app/api/index.php?section=editCategory', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async delete(id){
        let data = {id: id};
        return fetch("/app/api/index.php?section=deleteCategory", {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

}
let expensesService = new ExpensesService();
class View {
    constructor() {
        this.addButton();
        this.tablePagination();
        this.formsData();
        this.cancelButtons();
    }

    cancelButtons(){
        document.getElementById('cancelForm').onclick = (event) => {
            event.preventDefault();
            document.getElementById('dialog-form').style.display = "none";
        };

        document.getElementById('cancelEditForm').onclick = (event) => {
            event.preventDefault();
            document.getElementById('edit-form').style.display = "none";
        };
    }

    addButton(){
        this.addButtonDiv = document.getElementById('addButtonDiv');
        this.addBtn = document.createElement('BUTTON');
        this.addBtn.innerText = 'Add New Category';
        this.addBtn.className = 'btn btn-success';
        this.addBtn.id = 'create-expense';
        this.addButtonDiv.appendChild(this.addBtn);

        this.addBtn.addEventListener("click", (event) => {
            event.preventDefault();
            document.getElementById('dialog-form').style.display = "block";
        });

    }

    appendData(data) {
        let generateTableHead = (table,data) => {
            let thead = table.createTHead();
            let row = thead.insertRow();
            for (let key of data) {
                let th = document.createElement("th");
                let text = document.createTextNode(key);
                th.appendChild(text);
                row.appendChild(th);
            }
            let action = document.createTextNode('action');
            let th = document.createElement("th");
            th.appendChild(action);
            row.appendChild(th);
        };

        let generateTable = (table, data) => {
            let tbody = table.createTBody();
            for (let element of data) {
                let row = tbody.insertRow();
                for (const key in element) {
                    let cell = row.insertCell();
                    let text = document.createTextNode(element[key]);
                    cell.appendChild(text);
                }
                let cell = row.insertCell();
                let removeBtn = document.createElement('BUTTON');
                removeBtn.innerText = 'Remove';
                removeBtn.className = 'btn btn-danger remove-btn';
                removeBtn.id = element.id;


                let editBtn = document.createElement('BUTTON');
                editBtn.innerText = 'Edit';
                editBtn.className = 'btn btn-warning';
                editBtn.setAttribute('data-type',element.type);
                editBtn.id = element.id;
                cell.appendChild(editBtn);
                cell.appendChild(removeBtn);

                editBtn.onclick = function(event){
                    event.preventDefault();
                    document.getElementById('edit-form').style.display = "block";

                    let id = document.getElementById(element.id).getAttribute('id');
                    let type = document.getElementById(element.id).getAttribute('data-type');
                    console.log(type);
                    document.getElementById('edit-type').value = type;
                    document.getElementById('editElementId').value = id;
                };


                removeBtn.addEventListener("click", (event) => {
                    let id = document.getElementById(element.id).getAttribute('id');
                    let row = removeBtn.parentNode.parentNode;
                    expensesService.delete(id).then( () => {
                        row.remove();
                        this.tablePagination();
                    }).catch(function (err) {
                        console.log('error: ' + err);
                    });

                });


            }
        };

        let Form = document.getElementById('editCategoryForm');
        Form.onsubmit = (event=> {
            event.preventDefault();
            let id = document.getElementById('editElementId').value;
            let type =document.getElementById('edit-type').value;
            let editData = {
                id: id,
                type: type
            };

            expensesService.editCategory(editData).catch(function (err) {
                console.log('error: ' + err);
            });
            document.getElementById('edit-form').style.display = "none";
            document.getElementById('myTable').innerHTML = '';
            expensesService.getAllCategories().then(data =>  {
                this.appendData(data);
                this.tablePagination();
                console.log(data);
            }).catch(function (err) {
                console.log('error: ' + err);
            });
        });
        this.table = document.querySelector("table");
        this.keys = Object.keys(data[0]);
        generateTableHead(this.table,this.keys);
        generateTable(this.table, data);
    }

    formsData() {
        let Form = document.getElementById('addCategoryForm');
        Form.onsubmit = (event =>{
            event.preventDefault();
            let type =document.getElementById('type').value;
            let data = {
                type: type
            };
            expensesService.addNewCategory(data).catch(function (err) {
                console.log('error: ' + err);
            });
            document.getElementById('dialog-form').style.display = "none";
            document.getElementById('myTable').innerHTML = '';
            expensesService.getAllCategories().then( data => {
                this.appendData(data);
                this.tablePagination();
                console.log(data);
            }).catch(function (err) {
                console.log('error: ' + err);
            });
        });
    }

     tablePagination () {
        expensesService.getAllCategories().then(data => {

            let state = {
                'querySet': data,
                'page': 1,
                'rows': 5,
                'window': 5,
            };

            let pagination = (querySet, page, rows) => {

                let trimStart = (page - 1) * rows;
                let trimEnd = trimStart + rows;

                let trimmedData = querySet.slice(trimStart, trimEnd);

                let pages = Math.round(querySet.length / rows);

                return {
                    'querySet': trimmedData,
                    'pages': pages,
                }
            };

            let pageButtons = (pages) => {
                let wrapper = document.getElementById('pagination-wrapper');

                wrapper.innerHTML = ``;
                console.log('Pages:', pages);

                let maxLeft = (state.page - Math.floor(state.window / 2));
                let maxRight = (state.page + Math.floor(state.window / 2));

                if (maxLeft < 1) {
                    maxLeft = 1;
                    maxRight = state.window;
                }

                if (maxRight > pages) {
                    maxLeft = pages - (state.window - 1);

                    if (maxLeft < 1){
                        maxLeft = 1;
                    }
                    maxRight = pages;
                }

                for (let page = maxLeft; page <= maxRight; page++) {
                    wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
                }

                if (state.page !== 1) {
                    wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
                }

                if (state.page !== pages) {
                    wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info">Last &#187;</button>`
                }

                $('.page').on('click', function() {
                    $('#table-body').empty();
                    state.page = Number($(this).val());
                    buildTable();
                })
            };
            let appTable = (array) => {
                this.appendData(array);
            };

            $('#search-input').on('keyup', function(){
               let value = $(this).val();
               console.log(value);

               let filter = searchTable(value,data);
                document.getElementById('myTable').innerHTML = '';
                appTable(filter);
            });

            let searchTable = (value, data) =>{
                let filteredData = [];

                for (let i = 0; i < data.length; i++){
                    value = value.toLowerCase();
                    let type = data[i].type.toLowerCase();

                    if(type.includes(value)){
                        filteredData.push(data[i]);
                    }
                }
                return filteredData;
            };

            let buildTable = () => {
                document.getElementById('myTable').innerHTML = '';
                let dataPages = pagination(state.querySet, state.page, state.rows);
                let tbody = document.getElementById('myTable').getElementsByTagName('tbody');
                tbody.id = 'table-body';
                pageButtons(dataPages.pages);
                this.appendData(dataPages.querySet);
            };
            buildTable();
        });
    }
}
let view = new View();





