class ExpensesService {
    constructor() {
    }

    async getAllExpense(){
        return fetch('/app/api/index.php?section=getExpenses').then(function (response) {
            return response.json();
        });
    }

    async addNewExpense(data){
        return fetch('/app/api/index.php?section=addExpense', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async getCategories() {
        return fetch('/app/api/index.php?section=getCategories').then(function (response) {
            return response.json();
        });
    }

    editExpense(data){
        return fetch('/app/api/index.php?section=editExpense', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async delete(id){
        return fetch("/app/api/index.php?section=deleteExpense&id="+id, {
            method: 'POST'
        });
    }

    async getCategoriesPer(){
        return fetch('/app/api/index.php?section=getCategoriesPer').then(function (response) {
            return response.json();
        })
    }

}
let expensesService = new ExpensesService();
class View {
    constructor() {
        this.addButton();
        this.tablePagination();
        this.formsData();
        this.cancelBtns();
    }

    cancelBtns(){
        document.getElementById('cancelForm').onclick = function (event) {
            event.preventDefault();
            document.getElementById('dialog-form').style.display = "none";
        };

        document.getElementById('cancelEditForm').onclick = function (event) {
            event.preventDefault();
            document.getElementById('edit-form').style.display = "none";
        };
    }

    addButton(){
        this.addButtonDiv = document.getElementById('addButtonDiv');
        this.addBtn = document.createElement('BUTTON');
        this.addBtn.innerText = 'Add New Expense';
        this.addBtn.className = 'btn btn-success';
        this.addBtn.id = 'create-expense';
        this.addButtonDiv.appendChild(this.addBtn);

        this.addBtn.addEventListener("click", function(event){
            event.preventDefault();
            expensesService.getCategories().then(function (data) {
                let html;
                for (let i = 0 ; i< data.length; i++){
                    html += '<option value="'+data[i].id+'">'+data[i].type+'</option>'
                }
                document.getElementById('type').innerHTML = html;
                document.getElementById('edit-type').innerHTML = html;
            }).catch(function (err) {
                console.log('error: ' + err);
            });
            document.getElementById('dialog-form').style.display = "block";
        });
    }

    appendData(data) {
         let generateTableHead = (table,data) => {
            let thead = table.createTHead();
            let row = thead.insertRow();
            for (let key of data) {
                let th = document.createElement("th");
                let text = document.createTextNode(key);
                th.appendChild(text);
                row.appendChild(th);
            }
            let action = document.createTextNode('action');
            let th = document.createElement("th");
            th.appendChild(action);
            row.appendChild(th);
        };

        let generateTable = (table, data) => {
            let tbody = table.createTBody();
            for (let element of data) {
                let row = tbody.insertRow();
                for (const key in element) {
                    let cell = row.insertCell();
                    let text = document.createTextNode(element[key]);
                    cell.appendChild(text);
                }
                let cell = row.insertCell();
                let removeBtn = document.createElement('BUTTON');
                removeBtn.innerText = 'Remove';
                removeBtn.className = 'btn btn-danger remove-btn';
                removeBtn.id = element.id;


                let editBtn = document.createElement('BUTTON');
                editBtn.innerText = 'Edit';
                editBtn.className = 'btn btn-warning';
                editBtn.setAttribute('data-amount',element.amount);
                editBtn.setAttribute('data-type',element.category_id);
                editBtn.setAttribute('data-date',element.date);
                editBtn.id = element.id;
                cell.appendChild(editBtn);
                cell.appendChild(removeBtn);

                editBtn.onclick = function(event){
                    event.preventDefault();
                    expensesService.getCategories().then(data => {
                        let html;
                        for (let i = 0 ; i< data.length; i++){
                            let sel = data[i].id === type ? 'SELECTED' : '';
                            html += '<option value="'+data[i].id+'" '+sel+' >'+data[i].type+'</option>'
                        }
                        document.getElementById('type').innerHTML = html;
                        document.getElementById('edit-type').innerHTML = html;
                    }).catch(function (err) {
                        console.log('error: ' + err);
                    });
                    document.getElementById('edit-form').style.display = "block";

                    let id = document.getElementById(element.id).getAttribute('id');
                    let amount = document.getElementById(element.id).getAttribute('data-amount');
                    let date = document.getElementById(element.id).getAttribute('data-date');
                    let type = document.getElementById(element.id).getAttribute('data-type');

                    document.getElementById('edit-amount').value = amount;
                    document.getElementById('edit-date').value = date;
                    document.getElementById('editElementId').value = id;
                };


                removeBtn.addEventListener("click", (event) => {
                    let id = document.getElementById(element.id).getAttribute('id');
                    let row = removeBtn.parentNode.parentNode;
                    expensesService.delete(id).then( () => {
                        row.remove();
                        this.tablePagination();
                    }).then( () => {
                        this.resetPieChart();
                    }).catch(function (err) {
                        console.log('error: ' + err);
                    });

                });


            }
        };

        let Form = document.getElementById('editExpenseForm');
        Form.onsubmit = (event=> {
            event.preventDefault();
            let id = document.getElementById('editElementId').value;
            let date = document.getElementById('edit-date').value;
            let amount = document.getElementById('edit-amount').value;
            let type =document.getElementById('edit-type').value;
            let editData = {
                id: id,
                date: date,
                amount: amount,
                category_id: type
            };

            expensesService.editExpense(editData).catch(function (err) {
                console.log('error: ' + err);
            });
            document.getElementById('edit-form').style.display = "none";
            document.getElementById('myTable').innerHTML = '';
            expensesService.getAllExpense().then(data =>  {
                this.appendData(data);
                this.resetPieChart();
                this.tablePagination();
                console.log(data);
            }).catch(function (err) {
                console.log('error: ' + err);
            });
        });
        this.table = document.querySelector("table");
        this.keys = Object.keys(data[0]);
        generateTableHead(this.table,this.keys);
        generateTable(this.table, data);
    }

    formsData() {
        let Form = document.getElementById('addExpenseForm');
        Form.onsubmit = (event =>{
            event.preventDefault();
            let date = document.getElementById('date').value;
            let amount = document.getElementById('amount').value;
            let type =document.getElementById('type').value;
            let data = {
                date: date,
                amount: amount,
                category_id: type
            };
            expensesService.addNewExpense(data).catch(function (err) {
                console.log('error: ' + err);
            });
            document.getElementById('dialog-form').style.display = "none";
            document.getElementById('myTable').innerHTML = '';
            expensesService.getAllExpense().then( data => {
                this.appendData(data);
                this.resetPieChart();
                this.tablePagination();
                console.log(data);
            }).catch(function (err) {
                console.log('error: ' + err);
            });
        });
    }

    resetPieChart() {
        document.getElementById('divPieChart').innerHTML = '';
        expensesService.getCategoriesPer().then(data => {
            let Score = [];
            let type = [];
            for (let i = 0; i < data.length; i++) {
                Score.push(data[i].Score);
                type.push(data[i].type);
            }

            let divChart = document.getElementById('divPieChart');
            let canvas = document.createElement('canvas');
            canvas.id = 'myChart';
            canvas.setAttribute('width',400);
            canvas.setAttribute('height',400);
            divChart.appendChild(canvas);
            let ctx = canvas.getContext('2d');
            let chart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: type,
                    datasets: [{
                        label: '# of Votes',
                        data: Score,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });

        }).catch(function (err) {
            console.log('error: ' + err);
        });
    }

    tablePagination() {
        expensesService.getAllExpense().then(data => {

            let state = {
                'querySet': data,
                'page': 1,
                'rows': 5,
                'window': 5,
            };

            let pagination = (querySet, page, rows) => {

                let trimStart = (page - 1) * rows;
                let trimEnd = trimStart + rows;

                let trimmedData = querySet.slice(trimStart, trimEnd);

                let pages = Math.round(querySet.length / rows);

                return {
                    'querySet': trimmedData,
                    'pages': pages,
                }
            };

            let pageButtons = (pages) => {
                let wrapper = document.getElementById('pagination-wrapper');

                wrapper.innerHTML = ``;
                console.log('Pages:', pages);

                let maxLeft = (state.page - Math.floor(state.window / 2));
                let maxRight = (state.page + Math.floor(state.window / 2));

                if (maxLeft < 1) {
                    maxLeft = 1;
                    maxRight = state.window;
                }

                if (maxRight > pages) {
                    maxLeft = pages - (state.window - 1);

                    if (maxLeft < 1){
                        maxLeft = 1;
                    }
                    maxRight = pages;
                }

                for (let page = maxLeft; page <= maxRight; page++) {
                    wrapper.innerHTML += `<button value=${page} class="page btn btn-sm btn-info">${page}</button>`
                }

                if (state.page !== 1) {
                    wrapper.innerHTML = `<button value=${1} class="page btn btn-sm btn-info">&#171; First</button>` + wrapper.innerHTML
                }

                if (state.page !== pages) {
                    wrapper.innerHTML += `<button value=${pages} class="page btn btn-sm btn-info">Last &#187;</button>`
                }

                $('.page').on('click', function() {
                    $('#table-body').empty();
                    state.page = Number($(this).val());
                    buildTable();
                });

                let appTable = (array) => {
                    this.appendData(array);
                };

                let paginate = () => {
                    this.tablePagination();
                };

                $('#search-input').on('keyup', function(){
                    let value = $(this).val();
                    if(value === ''){
                        paginate();
                    }
                    console.log(value);

                    let filter = searchTable(value,data);
                    document.getElementById('myTable').innerHTML = '';
                    appTable(filter);
                });

                let searchTable = (value, data) =>{
                    let filteredData = [];

                    for (let i = 0; i < data.length; i++){
                        value = value.toLowerCase();
                        let amount = data[i].amount.toLowerCase();

                        if(amount.includes(value)){
                            filteredData.push(data[i]);
                        }
                    }
                    return filteredData;
                };
            };

            let buildTable = () => {
                document.getElementById('myTable').innerHTML = '';
                let dataPages = pagination(state.querySet, state.page, state.rows);
                let tbody = document.getElementById('myTable').getElementsByTagName('tbody');
                tbody.id = 'table-body';
                pageButtons(dataPages.pages);
                this.appendData(dataPages.querySet);
            };
            buildTable();
        });
    }
}
let view = new View();
 view.resetPieChart();