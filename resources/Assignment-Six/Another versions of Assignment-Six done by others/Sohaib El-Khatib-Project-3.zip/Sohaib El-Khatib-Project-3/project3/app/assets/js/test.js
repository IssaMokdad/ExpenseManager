// function getAllExpense(){
// fetch('/app/api/index.php?section=getExpenses').then(function (response) {
//     return response.json();
//     }).then(function (data) {
//         appendData(data);
//     resetPieChart();
//         console.log(data);
//     }).catch(function (err) {
//         console.log('error: ' + err);
//     });
// }
// getAllExpense();
// function addNewExpense(data){
//     fetch('/app/api/index.php?section=addExpense', {
//         method: 'POST',
//         body: JSON.stringify(data)
//     }).catch(function (err) {
//         console.log('error: ' + err);
//     });
// }
//
// function getCategories() {
//     fetch('/app/api/index.php?section=getCategories').then(function (response) {
//         return response.json();
//     }).then(function (data) {
//         let html;
//         for (let i = 0 ; i< data.length; i++){
//             html += '<option value="'+data[i].id+'">'+data[i].type+'</option>'
//         }
//         document.getElementById('type').innerHTML = html;
//         document.getElementById('edit-type').innerHTML = html;
//     }).catch(function (err) {
//         console.log('error: ' + err);
//     });
// }
//
// function editNewExpense(data){
//     fetch('/app/api/index.php?section=editExpense', {
//         method: 'POST',
//         body: JSON.stringify(data)
//     }).catch(function (err) {
//         console.log('error: ' + err);
//     });
// }
//
// let addButtonDiv = document.getElementById('addButtonDiv');
//
// let addBtn = document.createElement('BUTTON');
// addBtn.innerText = 'Add New Expense';
// addBtn.className = 'btn btn-success';
// addBtn.id = 'create-expense';
//
// addButtonDiv.appendChild(addBtn);
//
// addBtn.addEventListener("click", function(event){
//     event.preventDefault();
//     getCategories();
//     document.getElementById('dialog-form').style.display = "block";
// });
//
// // formsData();
// // function formsData() {
//     let Form = document.getElementById('addExpenseForm');
//     Form.onsubmit = function(event){
//         event.preventDefault();
//         let date = document.getElementById('date').value;
//         let amount = document.getElementById('amount').value;
//         let type =document.getElementById('type').value;
//         let data = {
//             date: date,
//             amount: amount,
//             category_id: type
//         };
//         addNewExpense(data);
//         document.getElementById('dialog-form').style.display = "none";
//         document.getElementById('myTable').innerHTML = '';
//         getAllExpense();
//     };
//
// // }
// function appendData(data) {
//     function generateTableHead(table,data) {
//         let thead = table.createTHead();
//         let row = thead.insertRow();
//         for (let key of data) {
//             let th = document.createElement("th");
//             let text = document.createTextNode(key);
//             th.appendChild(text);
//             row.appendChild(th);
//         }
//         let action = document.createTextNode('action');
//         let th = document.createElement("th");
//         th.appendChild(action);
//         row.appendChild(th);
//     }
//
//     function generateTable(table, data) {
//         for (let element of data) {
//             let row = table.insertRow();
//             for (key in element) {
//                 let cell = row.insertCell();
//                 let text = document.createTextNode(element[key]);
//                 cell.appendChild(text);
//             }
//             let cell = row.insertCell();
//             let removeBtn = document.createElement('BUTTON');
//             removeBtn.innerText = 'Remove';
//             removeBtn.className = 'btn btn-danger remove-btn';
//             removeBtn.id = element.id;
//
//
//             let editBtn = document.createElement('BUTTON');
//             editBtn.innerText = 'Edit';
//             editBtn.className = 'btn btn-warning';
//             editBtn.setAttribute('data-amount',element.amount);
//             editBtn.setAttribute('data-type',element.category_id);
//             editBtn.setAttribute('data-date',element.date);
//             editBtn.id = element.id;
//             cell.appendChild(editBtn);
//             cell.appendChild(removeBtn);
//
//             editBtn.onclick = function(event){
//                 event.preventDefault();
//                 getCategories();
//                 document.getElementById('edit-form').style.display = "block";
//
//                 let id = document.getElementById(element.id).getAttribute('id');
//                 let amount = document.getElementById(element.id).getAttribute('data-amount');
//                 let date = document.getElementById(element.id).getAttribute('data-date');
//                 let type = document.getElementById(element.id).getAttribute('data-type');
//
//                 document.getElementById('edit-amount').value = amount;
//                 document.getElementById('edit-date').value = date;
//                 document.getElementById('edit-type').value = type;
//                 document.getElementById('editElementId').value = id;
//
//             };
//
//
//             removeBtn.addEventListener("click", function(event){
//                 let id = document.getElementById(element.id).getAttribute('id');
//                 let row = this.parentNode.parentNode;
//                 fetch("/app/api/index.php?section=deleteExpense&id="+id, {
//                     method: 'POST'
//                 }).then(function () {
//                     row.remove();
//                 }).then(function () {
//                     resetPieChart();
//                 }).catch(function (err) {
//                     console.log('error: ' + err);
//                 });
//
//             });
//
//
//         }
//     }
//
//     let Form = document.getElementById('editExpenseForm');
//     Form.onsubmit = function(event){
//         event.preventDefault();
//         let id = document.getElementById('editElementId').value;
//         let date = document.getElementById('edit-date').value;
//         let amount = document.getElementById('edit-amount').value;
//         let type =document.getElementById('edit-type').value;
//         let editData = {
//             id: id,
//             date: date,
//             amount: amount,
//             category_id: type
//         };
//
//         editNewExpense(editData);
//         document.getElementById('edit-form').style.display = "none";
//         document.getElementById('myTable').innerHTML = '';
//         getAllExpense();
//         // resetPieChart();
//     };
//     let table = document.querySelector("table");
//     let keys = Object.keys(data[0]);
//     generateTableHead(table,keys);
//     generateTable(table, data);
// }
//
// function resetPieChart() {
//     let Score = [];
//     let type = [];
//     fetch('/app/api/index.php?section=getCategoriesPer').then(function (response) {
//         return response.json();
//     }).then(function (data) {
//
//         for (let i = 0; i < data.length; i++) {
//             Score.push(data[i].Score);
//             type.push(data[i].type);
//         }
//
//         let ctx = document.getElementById('myChart').getContext('2d');
//         new Chart(ctx, {
//             type: 'pie',
//             data: {
//                 labels: type,
//                 datasets: [{
//                     label: '# of Votes',
//                     data: Score,
//                     backgroundColor: [
//                         'rgba(255, 99, 132, 0.2)',
//                         'rgba(54, 162, 235, 0.2)',
//                         'rgba(255, 206, 86, 0.2)',
//                         'rgba(75, 192, 192, 0.2)',
//                         'rgba(153, 102, 255, 0.2)',
//                         'rgba(255, 159, 64, 0.2)'
//                     ],
//                     borderColor: [
//                         'rgba(255, 99, 132, 1)',
//                         'rgba(54, 162, 235, 1)',
//                         'rgba(255, 206, 86, 1)',
//                         'rgba(75, 192, 192, 1)',
//                         'rgba(153, 102, 255, 1)',
//                         'rgba(255, 159, 64, 1)'
//                     ],
//                     borderWidth: 1
//                 }]
//             },
//             options: {
//                 scales: {
//                     yAxes: [{
//                         ticks: {
//                             beginAtZero: true
//                         }
//                     }]
//                 }
//             }
//         });
//
//     }).catch(function (err) {
//         console.log('error: ' + err);
//     });
// }
// // resetPieChart();
//
// document.getElementById('cancelForm').onclick = function (event) {
//     event.preventDefault();
//     document.getElementById('dialog-form').style.display = "none";
// };
//
// document.getElementById('cancelEditForm').onclick = function (event) {
//     event.preventDefault();
//     document.getElementById('edit-form').style.display = "none";
// };