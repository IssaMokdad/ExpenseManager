<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'admin');
define('DB_PASS', '123456@aA');
define('DB_NAME', 'project_3');

define('APPROOT', dirname(dirname(__FILE__)));

define('URLROOT', 'http://localhost:8000/public');

define("ROOT_PATH", "/project3");

define('SITENAME', 'Project #3');

define('APPVERSION', '1.0.0');