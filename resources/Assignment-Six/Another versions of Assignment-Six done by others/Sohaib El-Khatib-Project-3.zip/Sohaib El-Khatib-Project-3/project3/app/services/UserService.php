<?php

class UserService
{

    private $db;

    public function __construct(){
        $this->db = new Database;
    }

    public function register(){
        // Sanitize POST
        $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

        $password = password_hash($post['password'],PASSWORD_BCRYPT);

        if($post['submit']){
            if($post['username'] == '' || $post['email'] == '' || $post['password'] == ''){
                Messages::setMsg('Please Fill In All Fields', 'error');
                return;
            }

            $stmt = $this->db;
            $stmt->query('SELECT id FROM users WHERE email = :email LIMIT 1');
            $stmt->bind(':email',$post['email']);
            $stmt->execute();
            $stmt->single();

            if ($stmt->countRows() == 1) {
                Messages::setMsg("Duplicate email", 'error');
                return;
            }

            if (!filter_var($post['email'], FILTER_VALIDATE_EMAIL)) {
                Messages::setMsg("Email field is not formatted correctly - {$post['email']}",'error');
                return;
            }

            // Insert into MySQL
            $this->db->query('INSERT INTO users (username, email, password) VALUES(:username, :email, :password)');
            $this->db->bind(':username', $post['username']);
            $this->db->bind(':email', $post['email']);
            $this->db->bind(':password', $password);
            try {
                $this->db->execute();
                if($this->db->lastInsertId()){
                    // Redirect
                    redirect('users/login');
                }
                Messages::setMsg("User Added Successfully ",'success');
            }catch (PDOException $e){
                Messages::setMsg('Adding User failed','error');
                return;
            }
        }
        return;
    }

    public function login(){
        // Sanitize POST
        $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

        if(isset($post['submit'])){
            // Compare Login
            $this->db->query('SELECT * FROM users WHERE email = :email');
            $this->db->bind(':email', $post['email']);

            $row = $this->db->single();
            if($row){
                if(password_verify($post['password'],$row->password)){
                    $_SESSION['is_logged_in'] = true;
                    $_SESSION['user_id'] = $row->id;
                    $_SESSION['user_data'] = [
                        "id"	=> $row->id,
                        "username"	=> $row->username,
                        "email"	=> $row->email,
                        "manager_id" => $row->manager_id
                    ];
                    header('Location: '.URLROOT.'/expenses');
                } else {
                    Messages::setMsg('Incorrect Password', 'error');
                    return;
                }
            }else {
                Messages::setMsg('Incorrect Email', 'error');
                return;
            }
        }
    }
}