<?php

class CategoriesService
{

    private $db;

    public function __construct(){
        $this->db = new Database;
    }

    //Get All Categories
    public function getCategories($startRow,$lastRow){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT * FROM categories WHERE user_id = :user_id  LIMIT :startRow,:lastRow;");

        $this->db->bind(':user_id', $user_id);
        $this->db->bind(':startRow', $startRow);
        $this->db->bind(':lastRow', $lastRow);

        $category =  $this->db->resultset();
        if (!$category){
            throw new Exception(' No Categories found');
        }
        return $category;
    }

    public function getCategoriesCount(){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT * FROM categories WHERE user_id = :user_id;");

        $this->db->bind(':user_id', $user_id);

        return $this->db->countRows();
    }

    // Get Category By ID
    public function getCategoryById($id){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT `id`,`user_id`,`type` FROM `categories` WHERE `id` = :id AND user_id = :user_id");

        $this->db->bind(':id', $id);
        $this->db->bind(':user_id', $user_id);

        $category = $this->db->single();

        if (!$category){
            throw new Exception('Category not found');
        }

        return $category;
    }

    // Add Category
    public function addCategory(CategoriesModel $category){
        // Prepare Query
        $query = 'INSERT INTO categories (user_id, type) 
      VALUES (:user_id, :type)';

        $this->db->query($query);
        // Bind Values
        $this->db->bind(':type', $category->type);
        $this->db->bind(':user_id', $category->user_id);

        try {
            $this->db->execute();
        }catch (PDOException $e){
            throw new Exception('Adding Category failed');
        }
        $category->id = $this->db->lastInsertId();

        return $category;
    }

    // Update Category
    public function updateCategory(CategoriesModel $category) {
        $user_id = $_SESSION['user_id'];
        if ($category->user_id == $user_id){
        // Prepare Query
        $stmt = $this->db;
        $stmt->query('UPDATE categories SET type = :type WHERE id = :id AND user_id = :user_id');

        // Bind Values
        $stmt->bind(':id', $category->id);
        $stmt->bind(':user_id', $category->user_id);
        $stmt->bind(':type', $category->type);

        try {
            $stmt->execute();
        }catch (PDOException $e){
            throw new Exception('Updating Category Failed');
        }
        }else{
            throw new Exception('You can not updated what is not yours');
        }
    }

    // Delete Category
    public function deleteCategory($id){
        $user_id = $_SESSION['user_id'];
        $categoryUser = $this->getCategoryById($id);
        if ($user_id == $categoryUser->user_id){
        // Prepare Query
        $this->db->query('DELETE FROM categories WHERE id = :id AND user_id = :user_id');

        // Bind Values
        $this->db->bind(':id', $id);
        $this->db->bind(':user_id', $user_id);

        //Execute
        try {
            $this->db->execute();
        }catch (Exception $e){
            echo $e->getMessage();
            throw new Exception('Category delete failed');
        }
        }else{
            throw new Exception('You can not delete what is not yours');
        }
    }

    // Delete Al Categories
    public function deleteAllCategories($userID){
        $user_id = $_SESSION['user_id'];
        if ($user_id == $userID){
        // Prepare Query
        $this->db->query('DELETE * FROM categories WHERE user_id = :user_id;');

        $this->db->bind(':user_id', $userID);

        //Execute
        if($this->db->execute()){
            return true;
        } else {
            return false;
        }
        }else{
            throw new Exception('You can not delete what is not yours');
        }
    }

}