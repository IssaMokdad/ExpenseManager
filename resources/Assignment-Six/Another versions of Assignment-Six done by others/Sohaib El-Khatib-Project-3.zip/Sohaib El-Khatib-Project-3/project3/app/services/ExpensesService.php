<?php

class ExpensesService
{
    private $db;

    public function __construct(){
        $this->db = new Database;
    }

    //Get All Expenses
    public function getExpenses(){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT e.id,e.user_id,u.username,e.date,e.amount,ca.type,e.category_id FROM expenses AS e
                              JOIN categories AS ca ON ca.id = e.category_id
                              JOIN users AS u ON u.id = e.user_id
                              WHERE e.user_id = :user_id;");

        $this->db->bind(':user_id', $user_id);

        $expenses =  $this->db->resultset();
        if (!$expenses){
            throw new Exception(' No Expenses found');
        }
        return $expenses;
    }

    public function getCategories(){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT * FROM categories AS c
                                WHERE c.user_id = :user_id ;");

        $this->db->bind(':user_id', $user_id);

        $categories =  $this->db->resultset();
        if (!$categories){
            throw new Exception(' No Categories found');
        }
        return $categories;
    }
//cast((Count(e.category_id)* 100 / (Select Count(category_id) From expenses as ex WHERE ex.user_id=u.id)) as decimal(3,0))
    public function getCategoriesPer(){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT  SUM(e.amount)as Score,ca.type
                              FROM expenses AS e
                              JOIN categories AS ca ON ca.id = e.category_id
                              JOIN users AS u ON u.id = e.user_id
                              WHERE e.user_id = :user_id
                              GROUP BY ca.type;");

        $this->db->bind(':user_id', $user_id);

        $expenses =  $this->db->resultset();
        if (!$expenses){
            throw new Exception(' No Expenses found');
        }
        return $expenses;
    }


    // Get Expense By ID
    public function getExpenseById($id){
        $user_id = $_SESSION['user_id'];
        $this->db->query("SELECT e.id,e.user_id,e.date,e.amount,ca.type FROM expenses AS e
                              JOIN categories AS ca ON ca.id = e.category_id
                              WHERE e.id = :id AND  e.user_id = :user_id;");

        $this->db->bind(':id', $id);
        $this->db->bind(':user_id', $user_id);

        $expenses = $this->db->single();

            if (!$expenses){
               throw new Exception('Expense not found');
            }
        return $expenses;
    }

    // Add Expense
    public function addExpense(ExpensesModel $expense){
        $user_id = $_SESSION['user_id'];
        // Prepare Query
        $query = 'INSERT INTO expenses (date, user_id, amount, category_id) 
      VALUES (:date, :user_id, :amount, :category_id)';

        $this->db->query($query);
        // Bind Values
        $this->db->bind(':user_id', $user_id);
        $this->db->bind(':date', $expense->date);
        $this->db->bind(':amount', $expense->amount);
        $this->db->bind(':category_id', $expense->category_id);

        try {
            $this->db->execute();
        }catch (PDOException $e){
            throw new Exception('Adding Expense failed');
        }
        $expense->id = $this->db->lastInsertId();

        return $expense;
    }

    // Update Expense
    public function updateExpense(ExpensesModel $expense) {
        $user_id = $_SESSION['user_id'];
        $expenseUser = $this->getExpenseById($expense->id);

        if ($user_id == $expenseUser->user_id){
        // Prepare Query
        $stmt = $this->db;
        $stmt->query('UPDATE expenses SET date = :date, amount = :amount, category_id = :category_id WHERE id = :id AND user_id = :user_id');

        // Bind Values
        $stmt->bind(':id', $expense->id);
        $stmt->bind(':user_id', $expense->user_id);
        $stmt->bind(':date', $expense->date);
        $stmt->bind(':amount', $expense->amount);
        $stmt->bind(':category_id', $expense->category_id);

        try {
            $stmt->execute();
        }catch (PDOException $e){
            throw new Exception('Updating Expense Failed');
        }
        }else{
            throw new Exception('You can not updated what is not yours');
        }

    }

    // Delete Expense
    public function deleteExpense($id){
        $user_id = $_SESSION['user_id'];
        $expenseUser = $this->getExpenseById($id);
        if ($user_id == $expenseUser->user_id){
        // Prepare Query
        $this->db->query('DELETE FROM expenses WHERE id = :id AND user_id = :user_id');

        // Bind Values
        $this->db->bind(':id', $id);
        $this->db->bind(':user_id', $user_id);

        //Execute
        try {
            $this->db->execute();
        }catch (Exception $e){
            throw new Exception('Expense delete failed');
        }
        }else{
            throw new Exception('You can not delete what is not yours');
        }
    }

    // Delete Al Expenses
    public function deleteAllExpenses($userID){
        $user_id = $_SESSION['user_id'];
        if ($user_id == $userID){
        // Prepare Query
        $this->db->query('DELETE * FROM expenses WHERE user_id = :user_id;');

        $this->db->bind(':user_id', $userID);
        //Execute
        if($this->db->execute()){
            return true;
        } else {
            return false;
        }
        }else{
            throw new Exception('You can not delete what is not yours');
        }
    }

}