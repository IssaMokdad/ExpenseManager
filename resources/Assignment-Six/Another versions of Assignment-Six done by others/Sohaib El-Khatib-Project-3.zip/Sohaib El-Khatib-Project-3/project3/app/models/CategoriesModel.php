<?php

class CategoriesModel
{
    public $id;
    public $user_id;
    public $type;

    public function __construct($id, $user_id, $type)
    {
        $this->id = $id;
        $this->user_id = $user_id;
        $this->type = $type;
    }
}

