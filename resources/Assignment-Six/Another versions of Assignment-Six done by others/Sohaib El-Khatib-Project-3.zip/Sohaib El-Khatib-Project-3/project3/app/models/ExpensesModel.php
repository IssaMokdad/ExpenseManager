<?php

class ExpensesModel
{
    public $id;
    public $user_id;
    public $date;
    public $amount;
    public $category_id;

    public function __construct($id, $user_id, $date, $amount,$category_id)
    {
        $this->id = $id;
        $this->user_id = $user_id;
        $this->date = $date;
        $this->amount = $amount;
        $this->category_id = $category_id;
    }
}

