<?php
require_once ('../app/models/UserModel.php');
require_once ('../app/models/ExpensesModel.php');
require_once ('../app/models/CategoriesModel.php');