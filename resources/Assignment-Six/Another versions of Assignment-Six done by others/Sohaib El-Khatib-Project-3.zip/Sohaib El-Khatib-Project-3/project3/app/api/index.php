<?php
require_once '../bootstrapApi.php';

header('Content-Type: application/json');
setcookie('cross-site-cookie', 'name', ['samesite' => 'None', 'secure' => true]);
function api() {

    $expenseService = new ExpensesService();
    $categoryService = new CategoriesService();
    $request_uri = $_SERVER['REQUEST_URI'];
    $request_method = $_SERVER['REQUEST_METHOD'];

    switch ($request_uri) {
        case $_GET['section'] == 'addExpense':
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            $request_json = json_decode(file_get_contents('php://input'));
            $expenseModel = new ExpensesModel(null,$_SESSION['user_id'],$request_json->date,$request_json->amount,$request_json->category_id);
            try {
                $data = $expenseService->addExpense($expenseModel);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }

            break;
        case $_GET['section'] == 'deleteExpense':
            $id = $_GET['id'];
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            try {
                $expenseService->deleteExpense($id);
            }catch (Exception $e){echo "sadfgh";
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }

            break;
        case $_GET['section'] == 'getExpenses':
            if ($request_method != 'GET') {
                http_response_code(404);
                return;
            }
            try {
                $data = $expenseService->getExpenses();
                http_response_code(200);
                echo json_encode($data);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'getCategoriesPer':
            if ($request_method != 'GET') {
                http_response_code(404);
                return;
            }
            try {
                $data = $expenseService->getCategoriesPer();
                http_response_code(200);
                echo json_encode($data,JSON_NUMERIC_CHECK, JSON_UNESCAPED_UNICODE);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'editExpense':
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            $request_json = json_decode(file_get_contents('php://input'));
            $expenseModel = new ExpensesModel($request_json->id,$_SESSION['user_id'],$request_json->date,$request_json->amount,$request_json->category_id);
            try {
                $expenseService->updateExpense($expenseModel);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'getCategories':
            if ($request_method != 'GET') {
                http_response_code(404);
                return;
            }
            try {
                $data = $expenseService->getCategories();
                http_response_code(200);
                echo json_encode($data);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case '/public/api/index/getExpenses':
            if ($request_method != 'GET') {
                http_response_code(404);
                return;
            }
            try {
                $data = $expenseService->getExpenses();
                http_response_code(200);
                echo json_encode($data);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'addCategory':
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            $request_json = json_decode(file_get_contents('php://input'));
            $categoryModel = new CategoriesModel(null,$_SESSION['user_id'],$request_json->type);
            try {
                $data = $categoryService->addCategory($categoryModel);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'editCategory':
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            $request_json = json_decode(file_get_contents('php://input'));
            $categoryModel = new CategoriesModel($request_json->id,$_SESSION['user_id'],$request_json->type);
            try {
                $categoryService->updateCategory($categoryModel);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
        case $_GET['section'] == 'deleteCategory':
            if ($request_method != 'POST') {
                http_response_code(404);
                return;
            }
            $request_json = json_decode(file_get_contents('php://input'));
            try {
                $categoryService->deleteCategory($request_json->id);
            }catch (Exception $e){
                http_response_code(404);
                echo json_encode(array("message" => $e->getMessage()));
                return;
            }
            break;
    }
}
api();