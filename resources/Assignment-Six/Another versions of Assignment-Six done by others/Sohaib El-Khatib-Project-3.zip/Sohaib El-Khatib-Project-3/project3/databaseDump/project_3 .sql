SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `project_3`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `type`) VALUES
(1, 1, 'category1'),
(2, 1, 'category2'),
(3, 1, 'category3'),
(4, 1, 'category5'),
(5, 1, 'category5'),
(6, 1, 'category6'),
(7, 2, 'Shopping'),
(8, 2, 'Clothing'),
(11, 1, 'test1'),
(12, 1, 'test2'),
(13, 1, 'test3'),
(15, 1, 'test5'),
(16, 1, 'test6'),
(17, 1, 'test7'),
(18, 1, 'test8'),
(19, 1, 'test9'),
(20, 1, 'test10'),
(21, 1, 'category7777'),
(22, 1, 'category77'),
(23, 1, 'football');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` double NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `user_id`, `date`, `amount`, `category_id`) VALUES
(5, 2, '2020-04-04', 150, 2),
(31, 1, '2020-03-31', 6060, 4),
(32, 1, '2020-03-31', 4646, 5),
(33, 1, '2020-03-24', 1245, 5),
(34, 1, '2020-03-31', 454, 1),
(35, 1, '2020-03-31', 5002, 1),
(36, 1, '2020-03-25', 2500, 5),
(37, 1, '2020-03-28', 3005, 2),
(38, 1, '2020-05-13', 1000, 5),
(39, 1, '2020-03-25', 11111, 1),
(40, 1, '2020-03-11', 43456, 4),
(41, 1, '2020-03-18', 123, 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'test', 'test@test.com', '$2y$10$pg2p8OiISLW8Z9mpM.WENOuR6v7VVpZcfeh4yRbij3lBAdoUDG/r6'),
(2, 'test2', 'test2@test.com', '$2y$10$dDuCrWQnFQgmnUYJain.HuaQnVAEZ4fCH/FGpPaphU11gBmVKVRaO'),
(3, 'test3', 'test3@test.com', '$2y$10$9mEakqSxdlvpeUAZeCTfWeeF6cnIoBIJ.x5uY2Out3D8EyJCbVEEa');

-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;