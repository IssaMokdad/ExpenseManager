<?php
	/**
	 *
	 */

	class ExpenseService extends Service
	{

		function __construct($mysqli){
			parent::__construct($mysqli);
		}
		
		function add(&$expense){
			try{
				$statement = $this->mysqli->prepare('INSERT INTO Expense (name, amount, date, categoryid, currencyid) values (?, ?, ?, ?, ?)');
				$statement->bind_param('sdsii', $expense->name, $expense->amount, $expense->date, $expense->categoryid, $expense->currencyid);
				$statement->execute();
				$expense->id = $this->mysqli->insert_id;
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error adding expense', 0, $e);
			}
		}

		function update($expense){
			try{
				$statement = $this->mysqli->prepare('UPDATE Expense SET name = ?, amount = ?, date = ?, categoryid = ?, currencyid = ? WHERE id = ?');
				$statement->bind_param('sdsiii', $expense->name, $expense->amount, $expense->date, $expense->categoryid, $expense->currencyid, $expense->id);
				$statement->execute();
				$statement->close();
			} catch(Exception $e) {
				throw new ServiceError('Error updating expense id ' . $expense->id, 0, $e);
			}
		}

		function get($id){
			try{
				$statement = $this->mysqli->prepare('SELECT * FROM Expense WHERE id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->bind_result($id, $name, $amount, $date, $categoryid, $currencyid);
				$statement->fetch();
				return new Expense($id, $name, $amount, $date, $categoryid, $currencyid);
			} catch(Exception $e) {
				throw new ServiceError('Error getting expense id ' . $id, 0, $e);
			}
		}

		function getAll(){
			try{
				$statement = $this->mysqli->prepare('SELECT * FROM Expense');
				$statement->execute();
				$statement->bind_result($id, $name, $amount, $date, $categoryid, $currencyid);
				$statement->store_result();
				if($statement->num_rows() > 0){
					$expenses = array();
					while($statement->fetch()){
						$expense = new Expense($id, $name, $amount, $date, $categoryid, $currencyid);
						$expenses[] = $expense;
					}
					return $expenses;
				}
				return new Expense($id, $name, $amount, $date, $categoryid, $currencyid);
			} catch(Exception $e){
				throw new ServiceError('Error getting all expenses', 0, $e);
			}
		}

		function delete($id){
			try{
				$statement = $this->mysqli->prepare('DELETE FROM Expense WHERE id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error deleting expense id ' . $id, 0, $e);
			}
		}

		function getUserExpenses($id){
			try{
				$statement = $this->mysqli->prepare('SELECT e.id, e.name, e.amount, e.date, e.categoryid, e.currencyid FROM Expense e join User_Expense ue on e.id = ue.expense_id where user_id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->bind_result($expenseid, $name, $amount, $date, $categoryid, $currencyid);
				$statement->store_result();
				if($statement->num_rows() > 0){
					$expenses = array();
					while($statement->fetch()){
						$expense = new Expense($expenseid, $name, $amount, $date, $categoryid, $currencyid);
						$expenses[] = $expense;
					}
					return $expenses;
				}
				return new Expense($expenseid, $name, $amount, $date, $categoryid, $currencyid);
			} catch(Exception $e){
				throw new ServiceError('Error getting user expenses', 0, $e);
			}
		}

		function addUserExpense($user_id, $expenseid){
			try{
				$statement = $this->mysqli->prepare('INSERT INTO User_expense (user_id, expense_id) values (?, ?)');
				$statement->bind_param('ii', $user_id, $expenseid);
				$statement->execute();
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error adding user expense n-n', 0, $e);
			}
		}
	}
?>