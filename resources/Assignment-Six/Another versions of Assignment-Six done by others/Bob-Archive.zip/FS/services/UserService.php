<?php
	/**
	 *
	 */

	class UserService extends Service
	{

		function __construct($mysqli){
			parent::__construct($mysqli);
		}
		
		function checkAlreadyExists($id){
			try{
				$statement = $this->mysqli->prepare('SELECT count(user_id) FROM UserTokens WHERE user_id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->bind_result($count);
				$statement->fetch();
				$statement->close();
				return $count;
			} catch(Exception $e) {
				throw new ServiceError('Error logging in', 0, $e);
			}
		}
        
        function login($username, $password){
            try{
				$statement = $this->mysqli->prepare('SELECT id, firstname, lastname, hashed_password FROM User WHERE username = ?');
				$statement->bind_param('s', $username);
				$statement->execute();
				$statement->bind_result($id, $firstname, $lastname, $hashed_password);
                $statement->fetch();
                $statement->close();
                // if(password_hash($password, 'md5') == $hashed_password){
                if($password == $hashed_password){
					if($this->checkAlreadyExists($id) == 1){
						$statement = $this->mysqli->prepare('UPDATE UserTokens SET token = ? where user_id = ?');
						$token = openssl_random_pseudo_bytes(16);
						$token = bin2hex($token);
						$statement->bind_param('si', $token, $id);
						$statement->execute();
						$statement->close();
						return [
							"user" => new User($id, $firstname, $lastname, $username, $hashed_password),
							"token" => $token
							];
					}
					else{
						$statement = $this->mysqli->prepare('INSERT INTO UserTokens (user_id, token) VALUES (?, ?)');
						$token = openssl_random_pseudo_bytes(16);
						$token = bin2hex($token);
						$statement->bind_param('is', $id, $token);
						$statement->execute();
						$statement->close();
						return [
							"user" => new User($id, $firstname, $lastname, $username, $hashed_password),
							"token" => $token
							];
					}
                }
                return null;
			} catch(Exception $e) {
				throw new ServiceError('Error logging in', 0, $e);
			}
        }

        function logout($token){
            try{
				$statement = $this->mysqli->prepare('DELETE FROM UserTokens WHERE token = ?');
				$statement->bind_param('s', $token);
				$statement->execute();
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error logging out', 0, $e);
			}
        }
		
		function checkToken($user_id, $token){
            try{
				$statement = $this->mysqli->prepare('SELECT token FROM UserTokens WHERE user_id = ?');
				$statement->bind_param('i', $user_id);
				$statement->execute();
				$statement->bind_result($dbToken);
                $statement->fetch();
                if($token == $dbToken)
                    return true;
                return false;
			} catch(Exception $e) {
				throw new ServiceError('Wrong user token', 0, $e);
			}
        }
	}
?>