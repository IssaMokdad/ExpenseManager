<?php
	/**
	 *
	 */

	class CategoriesService extends Service
	{

		function __construct($mysqli){
			parent::__construct($mysqli);
		}

		function getSumOfExpenseOfThisCategory($user_id){
			try{
				$statement = $this->mysqli->prepare('SELECT c.name, SUM(e.amount) FROM User_Expense ue JOIN Expense e ON ue.expense_id = e.id AND ue.user_id = 1 JOIN Category c ON e.categoryid = c.id GROUP BY c.name;');
				$statement->bind_param('i', $user_id);
				$statement->execute();
				$statement->bind_result($categoryname, $sum);
				$statement->store_result();
				if($statement->num_rows() > 0){
					$pieChartData = array();
					while($statement->fetch()){
						$data = new PieChartData($categoryname, $sum);
						$pieChartData[] = $data;
					}
					return $pieChartData;
				}
				return new PieChartData($categoryname, $sum);
			} catch(Exception $e){
				throw new ServiceError('Error getting all expenses of sum (PIECHARTDATA)', 0, $e);
			}
		}
		
		function add(&$category){
			try{
				$statement = $this->mysqli->prepare('INSERT INTO Category (name) values (?)');
				$statement->bind_param('s', $category->name);
				$statement->execute();
				$category->id = $this->mysqli->insert_id;
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error adding category', 0, $e);
			}
		}

		function update($category){
			try{
				$statement = $this->mysqli->prepare('UPDATE Category SET name = ? WHERE id = ?');
				$statement->bind_param('si', $category->name, $category->id);
				$statement->execute();
				$statement->close();
			} catch(Exception $e) {
				throw new ServiceError('Error updating category id ' . $category->id, 0, $e);
			}
		}

		function get($id){
			try{
				$statement = $this->mysqli->prepare('SELECT * FROM Category WHERE id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->bind_result($id, $name);
				$statement->fetch();
				return new Category($id, $name);
			} catch(Exception $e) {
				throw new ServiceError('Error getting category id ' . $id, 0, $e);
			}
		}

		function getAll(){
			try{
				$statement = $this->mysqli->prepare('SELECT * FROM Category');
				$statement->execute();
				$statement->bind_result($id, $name);
				$statement->store_result();
				if($statement->num_rows() > 0){
					$categories = array();
					while($statement->fetch()){
						$category = new Category($id, $name);
						$categories[] = $category;
					}
					return $categories;
				}
				return new Category($id, $name);
			} catch(Exception $e){
				throw new ServiceError('Error getting all categories', 0, $e);
			}
		}

		function delete($id){
			try{
				$statement = $this->mysqli->prepare('DELETE FROM Categories WHERE id = ?');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error deleting category id ' . $id, 0, $e);
			}
		}

		function getUserCategories($id){
			try{
				$statement = $this->mysqli->prepare('SELECT c.id, c.name from Category c join User_Category C2 on c.id = C2.category_id where user_id = ?;');
				$statement->bind_param('i', $id);
				$statement->execute();
				$statement->bind_result($categoryid, $categoryName);
				$statement->store_result();
				if($statement->num_rows() > 0){
					$categories = array();
					while($statement->fetch()){
						$category = new Category($categoryid, $categoryName);
						$categories[] = $category;
					}
					return $categories;
				}
				return new Category($categoryid, $categoryName);
			} catch(Exception $e){
				throw new ServiceError('Error getting all user categories', 0, $e);
			}
		}

		function addUserCategory($user_id, $categoryid){
			try{
				$statement = $this->mysqli->prepare('INSERT INTO User_Category (user_id, category_id) values (?, ?)');
				$statement->bind_param('ii', $user_id, $categoryid);
				$statement->execute();
				$statement->close();
			} catch(Exception $e){
				throw new ServiceError('Error adding user category', 0, $e);
			}
		}
	}
?>