<?php
	require($_SERVER['DOCUMENT_ROOT'] . '/data/db.php');
	require($_SERVER['DOCUMENT_ROOT'] . '/data/Models.php');
	require 'ExpenseService.php';
	require 'CategoriesService.php';
	require 'UserService.php';

	/**
	 * An abstract class Service that is the root of all services available
	 */
	abstract class Service
	{
		protected $mysqli;
		
		function __construct($mysqli)
		{
			$this->mysqli = $mysqli;
		}
	}

	/**
	 * Class ServiceError handles exceptions just like Exception but allows to include a custom message
	 */
	class ServiceError extends Exception
	{
		
		function __construct($message = null, $code = 0, Exception $previous = null)
		{
			parent::__construct($message, $code, $previous);
		}
	}

	/**
	 * 
	 */
	class Services
	{
		public $expenseService;	
		public $categoriesService;
		public $userService;
		
		function __construct($mysqli)
		{
			$this->expenseService = new ExpenseService($mysqli);
			$this->categoriesService = new CategoriesService($mysqli);
			$this->userService = new UserService($mysqli);
		}
	}

	$services = new Services($mysqli);
	

	function sanitizeString($var){
		if(get_magic_quotes_gpc()){
			$var = stripslashes($var);
		}
		$var = strip_tags($var);
		$var = htmlentities($var);
		return $var;
	}

	return $services;
?>