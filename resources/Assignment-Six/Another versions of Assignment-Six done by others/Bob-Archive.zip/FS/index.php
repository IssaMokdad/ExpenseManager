<?php
    require('services/Services.php');
    //This is my foken router

    $method = $_SERVER['REQUEST_METHOD']; // getting the http request method
    $reqUri = $_SERVER['REQUEST_URI']; // getting the request full URI
    $uri = explode('/', $reqUri);

    if($uri[1] == 'login'){
        include($_SERVER['DOCUMENT_ROOT'] .  '/public/login.php');
    }
    else{
        include($_SERVER['DOCUMENT_ROOT'] .  '/public/index.php');
        if($uri[1] == 'about'){
            include($_SERVER['DOCUMENT_ROOT'] .  '/public/views/about.php');
        }
    }
?>