<?php
    // $services = require($_SERVER['DOCUMENT_ROOT'] . '/services/Services.php');
    require('../services/Services.php');
    header('Content-Type: application/json');
    
    function route($services){
        $method = $_SERVER['REQUEST_METHOD']; // getting the http request method
	    $reqUri = $_SERVER['REQUEST_URI']; // getting the request full URI
        $uri = explode('/', $reqUri);

        if(!isset($uri[1]) || $uri[1] == '' || $uri[1] != 'api'){
            http_response_code(404);
            exit();
        }
        switch($method){
            case 'POST':
                $json = file_get_contents('php://input');
                $data = json_decode($json, true);
                if($uri[2] == 'login'){
                    $result = $services->userService->login($data['username'], $data['password']);
                    if($result == null){
                        echo '{"message": "Failed login"}';
                        exit(); // TODO: return instead of exit()
                    }
                    echo json_encode($result);
                    // echo '{"message": "Logged in", "token": "' . $result['token'] . '"}';
                    exit();
                }
                else if ($uri[2] == 'logout'){
                    $services->userServices->logout($data['token']);
                    echo '{"message": "Logged out"}';
                    exit();
                }
                
                $user_id = $data['user_id'];
                $token = $data['token'];
                if(!$services->userService->checkToken($user_id, $token)){
                    echo '{"message": "Invalid Token"}';
                    exit();
                }
                if($uri[2] == 'pie'){
                    $pieChartData = $services->categoriesService->getSumOfExpenseOfThisCategory($user_id);
                    echo json_encode($pieChartData);
                    exit();
                }
                if($uri[2] == 'expenses'){
                    // if($uri[3] == 'get' && $uri[4] != ''){
                    //     $expense = $services->expenseService->get($uri[4]);
                    //     echo json_encode($expense);
                    //     exit();
                    // }
                    if($uri[3] == 'getAll'){
                        $expenses = $services->expenseService->getUserExpenses($user_id);
                        echo json_encode($expenses, true);
                        exit();
                    }
                    else if($uri[3] == 'add'){
                        $name = $data['name'];
                        $amount = $data['amount'];
                        $date = $data['date'];
                        $categoryid = $data['categoryid'];
                        $currencyid = $data['currencyid'];
                        $expense = new Expense(null, $name, $amount, $date, $categoryid, $currencyid);
                        $services->expenseService->add($expense);
                        $services->expenseService->addUserExpense($user_id, $expense->id);
                        echo '{"message": "added", "id": "' . $expense->id . '"}';
                        exit();
                    }
                    else if($uri[3] == 'edit'){
                        $id = $data['id'];
                        $name = $data['name'];
                        $amount = $data['amount'];
                        $date = $data['date'];
                        $categoryid = $data['categoryid'];
                        $currencyid = $data['currencyid'];
                        $expense = new Expense($id, $name, $amount, $date, $categoryid, $currencyid);
                        $expenses = $services->expenseService->update($expense);
                        echo '{"message": "edited"}';
                        exit();
                    }
                }
                else if ($uri[2] == 'categories'){
                    if($uri[3] == 'get' && $uri[4] != ''){
                        $category = $services->categoriesService->get($uri[4]);
                        echo json_encode($category);
                        exit();
                    }
                    else if($uri[3] == 'getAll'){
                        $categories = $services->categoriesService->getUserCategories($user_id);
                        echo json_encode($categories, true);
                        exit();
                    }
                    else if($uri[3] == 'add'){
                        $name = $data['name'];
                        $category = new Category(null, $name);
                        $services->categoriesService->add($category);
                        $services->categoriesService->addUserCategory($user_id, $category->id);
                        echo '{"message": "added", "id": "' . $category->id . '"}';
                        exit();
                    }
                }
                http_response_code(404);
                exit();
            break;
            case 'DELETE':
                $json = file_get_contents('php://input');
                $data = json_decode($json, true);
                $user_id = $data['user_id'];
                $token = $data['token'];
                if(!$services->userService->checkToken($user_id, $token)){
                    echo '{"message": "Invalid Token"}';
                    exit();
                }
                if($uri[2] == 'expenses'){
                    if($uri[3] == 'delete' && $uri[4] != ''){
                        $services->expenseService->delete($uri[4]);
                        echo '{"message": "deleted"}';
                        exit();
                    }
                }
                http_response_code(404);
                exit();
            break;
            default:
                http_response_code(404);
                exit();
        }
    }

    route($services);
?>