<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="/public/css/bootstrap.min.css">
        <style>
            body {
                padding-top: 50px;
                padding-bottom: 20px;
            }
        </style>
        <script src=https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js></script>
        <link rel="stylesheet" href="/public/css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="/public/css/main.css">
        <link rel="stylesheet" type="text/css" href="/public/css/table.css">

        <script src="/public/js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="./">Expense Tracker</a>
          <button id="expensesButton" class="btn btn-primary btn-lg">Expenses</button>
          <button id="categoriesButton" class="btn btn-primary btn-lg">Categories</button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          
        </div><!--/.navbar-collapse -->
      </div>
    </nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1>Welcome</h1>
        <p>Welcome to Expense Tracker</p>
        <p><a class="btn btn-primary btn-lg" href="/about" role="button">Learn more &raquo;</a></p>
      </div>
    </div>
    <div class="container">
      <div class="container" id="mainContainer">

      </div>
      <hr>
      <footer>
        <p>&copy; BobKek 1612</p>
      </footer>
    </div> <!-- /container -->
        <script src="/public/js/vendor/bootstrap.min.js"></script>
        <script src="/public/js/main.js"></script>
    </body>
</html>
