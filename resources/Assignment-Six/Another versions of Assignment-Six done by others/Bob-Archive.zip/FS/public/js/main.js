
class LoginView{
    constructor(loginFunc, refreshExpenses){
        this.view = null;
        this.loginFunc = loginFunc;
        this.refreshExpenses = refreshExpenses;
        this.viewInitialize();
    }

    viewInitialize(){
        this.view = document.createElement('div');
        this.view.id = 'loginDiv';

        // div that holds the form
        let formGroup = document.createElement('div'); // div form for css
        formGroup.className = 'form-group';
        
        // Username and password fields
        let usernameInput = document.createElement('input');
        usernameInput.className = 'form-control';
        usernameInput.placeholder = 'Username';
        let passwordInput = document.createElement('input');
        passwordInput.type = 'password';
        passwordInput.className = 'form-control';
        passwordInput.placeholder = 'Password';

        // The login button
        let submitButton = document.createElement('button');
        submitButton.className = 'btn btn-success';
        submitButton.textContent = 'Login';
        submitButton.addEventListener('click', async () =>{
            let result = await this.loginFunc(usernameInput.value, passwordInput.value);
            if(result == false){
                usernameInput.value = '';
                passwordInput.value = '';
            }
            this.refreshExpenses();
        });

        //trigger login on Enter key press
        passwordInput.addEventListener('keypress', event => {
            if(event.keyCode == 13)
                submitButton.click();
        });

        // Displaying using append
        formGroup.append(usernameInput, passwordInput, submitButton);
        this.view.append(formGroup);
    }
}

class ExpensesView{

    constructor(expenses, categories, saveExpense, saveCategory, deleteExpense, getCanvasInfo){
        this.view = null;
        this.expenses = expenses;
        this.categories = categories;
        this.saveExpense = saveExpense;
        this.saveCategory = saveCategory;
        this.deleteExpense = deleteExpense;
        this.getCanvasInfo = getCanvasInfo;
        this.viewInitialize();
    }

    updateChart(chart, label, data = null){
        chart.data.labels.push(label);
        if(data != null)
            chart.data.datasets.forEach((dataset) => {
                dataset.data.push(data);
            });
        chart.update();
    }

    async initializeChart(canvas){
        //Chart default font size
        Chart.defaults.global.defaultFontSize = 15;

        // Canvas element
        canvas.id = 'myChart';
        const context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);

        let canvasInfo = await this.getCanvasInfo(); // get canvas info
        let categoryNames = []; // categories
        let sums = []; // actual data of sums
        
        let colors = [];
        
        canvasInfo.forEach(element => {
            categoryNames.push(element.categoryname);
            sums.push(element.sumOfExpenseOfThisCategory);
            let letters = '0123456789ABCDEF';
            let color = '#';
            for (var i = 0; i < 6; i++) {
                let random = Math.random() * 16;
                color += letters[Math.floor(random)]; // assign a random color
            }
            colors.push(color); // push this color onto this sums value
        });
        let chart = new Chart(canvas, {
            type: 'pie',
            data: {
              labels: categoryNames,
              datasets: [
                {
                  label: 'Total Amount of Expenses Per Category',
                  data: sums,
                  backgroundColor: colors
                }
              ]
            },
            options: {
              animation: {
                animateScale: true,
              }
            }
          });
          return chart;
    }

    async viewInitialize() {
        this.view = document.createElement('div');
        this.view.id = 'expensesView';

        //Chart View
        let canvas = document.createElement('canvas');
        let chart = await this.initializeChart(canvas);
        this.view.appendChild(canvas);


        let table = document.createElement('div');
        let categoryInput = document.createElement('select');

        //Add Category View
        let formGroup = document.createElement('div');
        formGroup.className = 'form-group';

        let nameInput = document.createElement('input');
        nameInput.className = 'form-control';
        nameInput.type = 'text';
        nameInput.name = 'categoryName';
        nameInput.placeholder = 'Enter category name';

        let addButton = document.createElement('button');
        addButton.type = 'submit';
        addButton.className = 'btn btn-success';
        addButton.textContent = 'Add Category';
        addButton.addEventListener('click', async () =>{
            try{
                if(nameInput.value == ''){
                    throw new Error('Empty category name');
                }
            }catch(e){
                console.error(e);
                return;
            }
            let category = {
                name: nameInput.value
            };
            category = await this.saveCategory(nameInput.value); // error handling, put in try
            let option = document.createElement('option');
            option.value = category.id;
            option.text = category.name;
            categoryInput.options.add(option);
            await this.initializeChart(canvas);
        });
        formGroup.append(nameInput, addButton);
        this.view.appendChild(formGroup);
        this.view.appendChild(document.createElement('hr'));

        //Add Expense View
        let formGroupExpense = document.createElement('div');
        formGroupExpense.className = 'form-group';

        let nameInputExpense = document.createElement('input');
        nameInputExpense.className = 'form-control';
        nameInputExpense.type = 'text';
        nameInputExpense.name = 'expenseName';
        nameInputExpense.placeholder = 'Enter expense name';

        let amountInput = document.createElement('input');
        amountInput.className = 'form-control';
        amountInput.type = 'text';
        amountInput.name = 'expenseAmount';
        amountInput.placeholder = 'Enter expense amount';

        let dateInput = document.createElement('input');
        dateInput.className = 'form-control';
        dateInput.type = 'date';
        dateInput.name = 'expenseDate';

        //category input value as name, and display as category name
        categoryInput.className = 'form-control';
        //options
        for(let i = 0; i < this.categories.length; i++){
            let option = document.createElement('option');
            option.value = this.categories[i].id;
            option.text = this.categories[i].name;
            categoryInput.options.add(option);
        }

        let addButtonExpense = document.createElement('button');
        addButtonExpense.type = 'submit';
        addButtonExpense.className = 'btn btn-success';
        addButtonExpense.textContent = 'Add Expense';
        addButtonExpense.addEventListener('click', async () =>{
            let expense = {
                name: nameInputExpense.value,
                amount: amountInput.value,
                date: dateInput.value,
                categoryid: categoryInput.value,
                currencyid: "1"
            };
            try{
                if(expense.name == '' || expense.amount == '' || expense.date == '' || expense.categoryid == '' || expense.currencyid == ''){
                    throw new Error('Empty field detected in new Expense');
                }
            }catch(e){
                console.error(e);
                return;
            }
            expense = await this.saveExpense(nameInputExpense.value, amountInput.value, dateInput.value, categoryInput.value, "1"); // 1 is currency
            this.dataAdder(table, expense);
            await this.initializeChart(canvas);
        });
        

        formGroupExpense.append(nameInputExpense, amountInput, dateInput, categoryInput, addButtonExpense);

        // Data View (Headers)
        let limiter = document.createElement('div');
        limiter.className = 'limiter';
        limiter.appendChild(formGroupExpense);

        let containerTable = document.createElement('div');
        containerTable.className = 'container-table100';
        limiter.appendChild(containerTable);

        let tableWrapper = document.createElement('div');
        tableWrapper.className = 'wrap-table100';
        containerTable.appendChild(tableWrapper);

        
        table.className = 'table';
        tableWrapper.appendChild(table);

        let rowHeader = document.createElement('div'); // header of table
        rowHeader.className = 'row header';
        table.appendChild(rowHeader);


        let cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Expense ID';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Name';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Amount';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Date';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Category Name';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Currency ID';
        rowHeader.appendChild(cell);

        cell = document.createElement('div'); // data in row header
        cell.className = 'cell';
        cell.textContent = 'Delete';
        rowHeader.appendChild(cell);

        let count = this.expenses.length;
        for(let i = 0; i < count; i++){
            this.dataAdder(table, this.expenses[i], canvas); // This will add all the data rows to the table
        }

        this.view.appendChild(limiter);
    }

    dataAdder(table, expense, canvas){
        let row = document.createElement('div'); // rows in the row element
        row.className = 'row';
        table.appendChild(row);

        let cell = document.createElement('div'); // data of Expense ID
        cell.className = 'cell';
        cell.textContent = expense.id;
        row.appendChild(cell);

        cell = document.createElement('div'); // data of Expense Name
        cell.className = 'cell';
        cell.textContent = expense.name;
        row.appendChild(cell);

        cell = document.createElement('div'); // data of Expense Amount
        cell.className = 'cell';
        cell.textContent = expense.amount;
        row.appendChild(cell);

        cell = document.createElement('div'); // data of Expense date
        cell.className = 'cell';
        cell.textContent = expense.date;
        row.appendChild(cell);
        
        // Display real name
        cell = document.createElement('div'); // Category ID
        cell.className = 'cell';
        cell.textContent = ((this.categories).find((cat) => cat.id == expense.categoryid)).name; // Getting the name of the category according to the id of the expense.categoryid
        row.appendChild(cell);

        cell = document.createElement('div'); // Currency ID
        cell.className = 'cell';
        cell.textContent = expense.currencyid;
        row.appendChild(cell);

        cell = document.createElement('button'); // Delete on ID
        cell.className = 'cell';
        cell.textContent = 'Delete';
        cell.addEventListener('click', async () =>{
            let result = confirm('Are you sure you want to delete expense ' + expense.name);
            if(result){
                this.deleteExpense(expense.id);
                await this.initializeChart(canvas);
                row.remove();
            }
        });
        row.appendChild(cell);
    }
}

class Service{
    
    constructor(){
        this.state = { expenses: [], categories: [], expense: [], token: "", user: ""};
    }

    setExpenses(data){
        this.state.expenses = data;
    }

    setCategories(data){
        this.state.categories = data;
    }

    setExpense(data){
        this.state.expense = data;
    }

    async loginFunc(username, password){
        let bodyReq = {"username": username, "password": password};
        let flag = true;
        let promise = fetch('/api/login', {method: 'POST', body: JSON.stringify(bodyReq)})
        .then((response) => response.json())
        .then((data) => {
            if(data.message === 'Failed login'){
                flag = false;
                return;
            }
            this.state.token = data.token;
            this.state.user = data.user;
        });
        await promise;
        return flag;
    }

    async getCanvasInfo(){
        let info = null;
        let bodyReq = {
            user_id: this.state.user.id,
            token: this.state.token
        };

        let promise = fetch('/api/pie', {method: 'POST', body: JSON.stringify(bodyReq)}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json()
        }).then((data) => {
            info = data;
        });
        await promise;
        return info;
    }

    async saveExpense(name, amount, date, categoryid, currencyid){
        let bodyReq = {
            id: "",
            name: name,
            amount: amount,
            date: date,
            categoryid: categoryid,
            currencyid: currencyid,
            user_id: this.state.user.id,
            token: this.state.token
        };

        let expense = {
            id: "",
            name: name,
            amount: amount,
            date: date,
            categoryid: categoryid,
            currencyid: currencyid
        };

        let promise = fetch('/api/expenses/add/', {method: 'POST', body: JSON.stringify(bodyReq)}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json()
        })
        .then((data) => {this.state.expenses.push(expense); expense.id = data.id;}).catch((error) => {console.log('Error: ' + error)});
        await promise;
        return expense;
    }

    async getExpenses(){
        let bodyReq = {
            "user_id": this.state.user.id,
            "token": this.state.token
        };
        let promise = fetch('/api/expenses/getAll/', {method: 'POST', body: JSON.stringify(bodyReq)}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json();
        })
        .then((data) => {this.setExpenses(data);}).catch((error) => {console.log('Error: ' + error)});
        await promise;
    }

    deleteExpense(id){
        let promise = fetch('/api/expenses/delete/' + id, {method: 'DELETE'}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json();
        })
        .then((data) => {this.getExpenses();}).catch((error) => {console.log('Error: ' + error)});
    }

    getExpense(id){
        let promise = fetch('/api/expenses/get/' + id).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json()
        })
        .then((data) => this.setExpense(data)).catch((error) => {console.log('Error: ' + error)});
    }

    async saveCategory(name){
        let bodyReq = {
            id: "",
            name: name,
            user_id: this.state.user.id,
            token: this.state.token
        };

        let category = {
            id: "",
            name: name
        };

        let promise = fetch('/api/categories/add/', {method: 'POST', body: JSON.stringify(bodyReq)}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json();
        })
        .then((data) => {this.state.categories.push(category); category.id = data.id;}).catch((error) => {console.log('Error: ' + error)});
        await promise;
        return category;
    }

    async getCategories(){
        let bodyReq = {
            user_id: this.state.user.id,
            token: this.state.token
        };
        let promise = fetch('/api/categories/getAll/', {method: 'POST', body: JSON.stringify(bodyReq)}).then((response) => {
            if(!response.ok)
                throw new Error('Network response was not ok');
            return response.json()
        })
        .then((data) => this.setCategories(data)).catch((error) => {console.log('Error: ' + error)});
        await promise;
    }
}
let service = new Service();

let mainContainer = document.getElementById('mainContainer');
let loginView = new LoginView(service.loginFunc.bind(service), refreshExpenses.bind(service));
mainContainer.appendChild(loginView.view);


let expensesButton = document.getElementById('expensesButton');
let categoriesButton = document.getElementById('categoriesButton');


expensesButton.addEventListener('click', () => {
        refreshExpenses(service);
});

async function refreshExpenses(service = null){
    if(service == null){
        service = this;
        // console.log('token inside refresh', service.state.token);
    }
    if(service.state.token != ""){
        await service.getExpenses();
        await service.getCategories();
        let mainContainer = document.getElementById('mainContainer');
        mainContainer.innerHTML = '';
        // console.log('test 1' + service.state.expenses);
        console.log('test--', service.state.expenses);
        console.log('test--', service.state.categories);
        
        let expensesView = new ExpensesView(service.state.expenses, service.state.categories, service.saveExpense.bind(service), service.saveCategory.bind(service), service.deleteExpense.bind(service), service.getCanvasInfo.bind(service));
        mainContainer.appendChild(expensesView.view);
    }
}
