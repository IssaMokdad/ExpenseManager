let mainContainer = document.getElementById('mainContainer');
mainContainer.innerHTML = '';
mainContainer.innerHTML = "<p>This is your expense tracker, in this website you can find information about your spendings.</p><p>You can also check your piechart.</p>";

