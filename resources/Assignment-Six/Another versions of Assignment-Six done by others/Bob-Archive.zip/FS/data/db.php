<?php
	require 'config.php';
	
	$mysqli = new mysqli($config['DB_HOST'], $config['DB_USERNAME'], $config['DB_PASSWORD'], $config['DB_NAME']);

	if($mysqli->connect_error)
		die("Error opening connection to database");
	

?>