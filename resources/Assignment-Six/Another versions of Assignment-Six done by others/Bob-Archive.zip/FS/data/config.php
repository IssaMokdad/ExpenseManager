<?php
	$config=array(
	'DB_HOST'=>'127.0.0.1',
	'DB_USERNAME'=>'bobkek',
	'DB_PASSWORD'=>'bobkek',
	'DB_NAME'=>'ExpenseTracker'
	);
?>