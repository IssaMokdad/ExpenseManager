<?php

    class Expense
    {
        public $id;
        public $amount;
        public $date;
        public $categoryid;
        public $currencyid;

        function __construct($id = null, $name, $amount, $date, $categoryid, $currencyid){
            $this->id = $id;
            $this->name = $name;
            $this->amount = $amount;
            $this->date = $date;
            $this->categoryid = $categoryid;
            $this->currencyid = $currencyid;
        }
    }

    class Category
    {
        public $id;
        public $name;

        function __construct($id, $name){
            $this->id = $id;
            $this->name = $name;
        }
    }
    
    class Currency
    {
        public $id;
        public $currency;

        function __construct($id, $name){
            $this->id = $id;
            $this->currency = $currency;
        }
    }
    
    class PieChartData
    {
        public $categoryname;
        public $sumOfExpenseOfThisCategory;

        function __construct($categoryname, $sumOfExpenseOfThisCategory){
            $this->categoryname = $categoryname;
            $this->sumOfExpenseOfThisCategory = $sumOfExpenseOfThisCategory;
        }
    }

    class User{
        public $id;
        public $firstname;
        public $lastname;
        public $username;
        public $hashed_password;

        function __construct($id, $firstname, $lastname, $username, $hashed_password)
        {
            $this->id = $id;
            $this->firstname = $firstname;
            $this->lastname = $lastname;
            $this->username = $username;
            $this->hashed_password = $hashed_password;
        }
    }

?>