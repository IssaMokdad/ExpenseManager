-- MySQL dump 10.13  Distrib 8.0.16, for osx10.13 (x86_64)
--
-- Host: 127.0.0.1    Database: ExpenseTracker
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` (`id`, `name`) VALUES (1,'Groceries'),(2,'Electronics'),(3,'Gym'),(4,'Shoes'),(5,''),(6,''),(7,''),(8,''),(9,'test1'),(10,'Food'),(11,'test'),(12,'test2'),(13,'newCat'),(14,'newCat2'),(15,'newcat22'),(16,'newcat3'),(17,'qqqqqqq'),(18,'qq'),(19,'12');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;

--
-- Table structure for table `Currency`
--

DROP TABLE IF EXISTS `Currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency` varchar(5) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Currency`
--

/*!40000 ALTER TABLE `Currency` DISABLE KEYS */;
INSERT INTO `Currency` (`id`, `currency`) VALUES (1,'USD'),(2,'EUR'),(3,'LBP');
/*!40000 ALTER TABLE `Currency` ENABLE KEYS */;

--
-- Table structure for table `Expense`
--

DROP TABLE IF EXISTS `Expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_general_ci NOT NULL,
  `amount` decimal(19,4) NOT NULL,
  `date` date NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `currencyid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_EXP_CAT` (`categoryid`),
  KEY `FK_EXP_CURR` (`currencyid`),
  CONSTRAINT `FK_EXP_CAT` FOREIGN KEY (`categoryid`) REFERENCES `category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_EXP_CURR` FOREIGN KEY (`currencyid`) REFERENCES `currency` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Expense`
--

/*!40000 ALTER TABLE `Expense` DISABLE KEYS */;
INSERT INTO `Expense` (`id`, `name`, `amount`, `date`, `categoryid`, `currencyid`) VALUES (53,'Larchleaf Beardtongue',56.8930,'2019-05-21',3,1),(54,'Roble Colorado',1.6299,'2017-06-20',4,2),(55,'Prostrate Dallis Grass',48.0707,'2019-07-19',1,1),(56,'Tortured Horsehair Lichen',89.7827,'2017-06-09',2,2),(57,'Runyon\'s Water-willow',96.9662,'2018-08-28',3,1),(58,'Smallfruit Primrose-willow',45.8206,'2019-03-08',4,2),(59,'Willow Dock',35.5338,'2018-11-12',1,1),(60,'Crenulate Mountain-avens',28.6141,'2018-12-25',2,2),(61,'Muscadine',8.5271,'2018-10-27',3,1),(62,'Mexican Pokeweed',28.2018,'2020-01-19',4,2),(63,'Slender Woollyheads',79.4900,'2019-03-12',1,1),(64,'Spoonleaf Sundew',64.3910,'2017-09-21',2,2),(65,'Gold-of-pleasure',72.1422,'2019-07-06',3,1),(66,'Large Clammyweed',20.6417,'2019-05-21',4,2),(67,'Herbaceous Seepweed',2.3795,'2018-02-26',1,1),(68,'Saltmarsh False Foxglove',84.3760,'2018-08-01',2,2),(69,'Soft Phlox',44.1538,'2018-05-06',3,1),(70,'keke',123.0000,'1111-11-11',1,1),(71,'okokokokko',12.0000,'1111-11-11',1,1),(72,'qqqqq',123.0000,'1111-11-11',1,1),(75,'name3',11.0000,'1111-11-11',4,1),(76,'name4',12.0000,'1111-11-11',1,1),(77,'name4',11.0000,'2010-11-11',1,1),(79,'qq',1.0000,'1111-11-11',1,1),(81,'agha',0.0000,'2010-01-01',3,1),(82,'agah2',1.0000,'2010-01-01',2,1),(83,'nemmm',1.0000,'1111-11-11',1,1),(84,'name',1.0000,'1111-11-11',3,1),(85,'nem',1.0000,'1111-11-11',1,1),(86,'name',121.0000,'1111-12-11',1,1),(96,'name1',12.0000,'1111-11-11',9,1),(97,'naewwew',12.0000,'1111-11-22',12,1),(98,'bob',12.0000,'1111-11-11',13,1),(99,'bobb',123.0000,'1111-11-11',13,1),(100,'bobb11',123.0000,'1111-11-11',11,1),(101,'test1',12.0000,'1111-11-11',10,1),(102,'tt',1223.0000,'1111-11-11',13,1),(103,'hamuruerher',2400.0000,'1111-11-11',10,1),(104,'12',121.0000,'1111-11-11',2,1),(105,'qwe',121.0000,'1111-11-11',9,1),(106,'test',12.0000,'1111-11-11',18,1),(107,'qtest',1200.0000,'1111-11-11',18,1),(108,'qtest',1200.0000,'1111-11-11',18,1),(109,'qtest',1200.0000,'1111-11-11',18,1),(110,'qtest',1200.0000,'1111-11-11',18,1),(111,'qtest',1200.0000,'1111-11-11',18,1),(112,'qtest',1200.0000,'1111-11-11',18,1),(113,'qtest',1200.0000,'1111-11-11',18,1),(114,'qtest',1200.0000,'1111-11-11',18,1),(115,'qtest',1200.0000,'1111-11-11',18,1),(116,'qtest',1200.0000,'1111-11-11',18,1),(117,'qtest',1200.0000,'1111-11-11',18,1),(118,'qtest',1200.0000,'1111-11-11',18,1),(119,'qtest',1200.0000,'1111-11-11',18,1),(120,'qtest',1200.0000,'1111-11-11',18,1),(121,'qtest',1200.0000,'1111-11-11',18,1),(122,'qtestfdsf',1200.0000,'1111-11-11',18,1),(123,'qtestfdsf',1200.0000,'1111-11-11',18,1),(124,'qtestfdsf',1200.0000,'1111-11-11',18,1),(125,'qtestfdsf',1200.0000,'1111-11-11',18,1),(126,'qtestfdsf',1200.0000,'1111-11-11',18,1),(127,'qtestfdsf',1200.0000,'1111-11-11',18,1),(128,'qtestfdsf',1200.0000,'1111-11-11',18,1),(129,'qtestfdsf',1200.0000,'1111-11-11',18,1),(130,'qtestfdsf',1200.0000,'1111-11-11',18,1),(131,'qtestfdsf',1200.0000,'1111-11-11',18,1),(132,'qtestfdsf',1200.0000,'1111-11-11',18,1),(133,'qtestfdsf',1200.0000,'1111-11-11',18,1),(134,'qtestfdsf',1200.0000,'1111-11-11',18,1),(135,'qtestfdsffsf',1200.0000,'1111-11-11',14,1),(136,'qtestfdsffsf',1200.0000,'1111-11-11',14,1),(137,'qtestfdsffsf',1200.0000,'1111-11-11',14,1),(138,'qtestfdsffsf',1200.0000,'1111-11-11',14,1),(139,'qtestfdsffsffs',2000.0000,'1111-11-11',9,1),(140,'qtestfdsffsffs',2000.0000,'1111-11-11',9,1),(141,'qtestfdsffsffsfadf',200.0000,'1111-11-11',1,1),(142,'qtestfdsffsffsfadf',200.0000,'1111-11-11',1,1),(143,'qtestfdsffsffsfadf',200.0000,'1111-11-11',1,1),(144,'qtestfdsffsffsfadf',200.0000,'1111-11-11',1,1);
/*!40000 ALTER TABLE `Expense` ENABLE KEYS */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `hashed_password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_UN` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` (`id`, `firstname`, `lastname`, `username`, `hashed_password`) VALUES (1,'bob','bob','bob','bob');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;

--
-- Table structure for table `User_Category`
--

DROP TABLE IF EXISTS `User_Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `User_Category` (
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`category_id`),
  KEY `User_Category_FK_1` (`category_id`),
  CONSTRAINT `User_Category_FK` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `User_Category_FK_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_Category`
--

/*!40000 ALTER TABLE `User_Category` DISABLE KEYS */;
INSERT INTO `User_Category` (`user_id`, `category_id`) VALUES (1,1),(1,2),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19);
/*!40000 ALTER TABLE `User_Category` ENABLE KEYS */;

--
-- Table structure for table `User_Expense`
--

DROP TABLE IF EXISTS `User_Expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `User_Expense` (
  `user_id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`expense_id`),
  KEY `User_Expense_FK_1` (`expense_id`),
  CONSTRAINT `User_Expense_FK` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `User_Expense_FK_1` FOREIGN KEY (`expense_id`) REFERENCES `expense` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_Expense`
--

/*!40000 ALTER TABLE `User_Expense` DISABLE KEYS */;
INSERT INTO `User_Expense` (`user_id`, `expense_id`) VALUES (1,96),(1,97),(1,98),(1,99),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,107),(1,108),(1,109),(1,110),(1,111),(1,112),(1,113),(1,114),(1,115),(1,116),(1,117),(1,118),(1,119),(1,120),(1,121),(1,122),(1,123),(1,124),(1,125),(1,126),(1,127),(1,128),(1,129),(1,130),(1,131),(1,132),(1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,139),(1,140),(1,141),(1,142),(1,143),(1,144);
/*!40000 ALTER TABLE `User_Expense` ENABLE KEYS */;

--
-- Table structure for table `UserTokens`
--

DROP TABLE IF EXISTS `UserTokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `UserTokens` (
  `user_id` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`user_id`,`token`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `usertokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTokens`
--

/*!40000 ALTER TABLE `UserTokens` DISABLE KEYS */;
INSERT INTO `UserTokens` (`user_id`, `token`) VALUES (1,'671f0c3226b2193023f33a53c1dacc7c');
/*!40000 ALTER TABLE `UserTokens` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:08:25
